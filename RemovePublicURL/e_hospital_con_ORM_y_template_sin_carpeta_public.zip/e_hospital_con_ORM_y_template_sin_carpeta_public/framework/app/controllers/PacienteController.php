<?php

class PacienteController extends BaseController {

	/*
	|--------------------------------------------------------------------------
	| Default Home Controller
	|--------------------------------------------------------------------------
	|
	| You may wish to use controllers instead of, or in addition to, Closure
	| based routes. That's great! Here is an example controller method to
	| get you started. To route to this controller, just add the route:
	|
	|	Route::get('/', 'HomeController@showWelcome');
	|
	*/

	public function consulta()
	{
		$pacientes = Paciente::all();
		return View::make('consulta')->with("pacientes", $pacientes);
	}

	public function pp(){
				return View::make("ingreso");

	}
	public function ingreso(){
		$paciente = new Paciente();
		$paciente->nombre = Input::get("nombre");
		$paciente->apellido = Input::get("apellido");
		$dia = Input::get("dia");
		$mes = Input::get("mes");
		$anio = Input::get("anio");
		$fecha = $anio."-".$mes."-".$dia;
		$paciente->fecha_alta = $fecha;
		$paciente->save();
		return View::make("ingreso");

	}
	public function baja(){
		$paciente = new Paciente();
		$paciente->delete(Input::get("id"));
		$pacientes = Paciente::all();
		return View::make('baja')->with("pacientes", $pacientes);
	}
	public function modifica(){


		$paciente = Paciente::find(Input::get("id_paciente"));

		$paciente->nombre = Input::get("nombre");
		$paciente->apellido = Input::get("apellido");
		$dia = Input::get("dia");
		$mes = Input::get("mes");
		$anio = Input::get("anio");


		$fecha = $anio."-".$mes."-".$dia;
		$paciente->fecha_alta = $fecha;

		$paciente->timestamps = false;
		$paciente->save();
//$paciente::updateOrCreate();



		$pacientes = Paciente::all();
		return View::make('modifica')->with("pacientes", $pacientes);
	}

}
