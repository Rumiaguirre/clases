<?php

/*
|--------------------------------------------------------------------------
| Application Routes
|--------------------------------------------------------------------------
|
| Here is where you can register all of the routes for an application.
| It's a breeze. Simply tell Laravel the URIs it should respond to
| and give it the Closure to execute when that URI is requested.
|
*/

Route::get('/', function()
{
	return View::make('init');
});
Route::get('/pp', function()
{
	return "hola";
});


Route::get('consulta', 'PacienteController@consulta');
Route::get('/ingreso', function(){
	return View::make("ingreso");
});
Route::any('/ingreso2', "PacienteController@ingreso");
Route::any('baja', function(){
	$pacientes = DB::table('paciente')->get();
	return View::make('baja')->with("pacientes", $pacientes);
});

Route::any('baja2', "PacienteController@baja");

Route::any('modifica', function(){
	$pacientes = DB::table('paciente')->get();
	return View::make('modifica')->with("pacientes", $pacientes);
});
Route::any('modifica2', "PacienteController@modifica");

//Route::get('/pp', array('as' => 'pp', 'uses' => 'PacienteController@pp'));