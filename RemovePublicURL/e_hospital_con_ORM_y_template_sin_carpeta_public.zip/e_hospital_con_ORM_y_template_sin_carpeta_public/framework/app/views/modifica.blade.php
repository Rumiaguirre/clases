@extends('layouts.master')

@section('titulo')
Modificación
@endsection

@section('contenido')
	{{ Form::open(array("url" => "modifica2")) }} 
	{{ Form::label("paciente", "Paciente")}}

	<select name="id_paciente" id="">
@foreach ($pacientes as $paciente)
	<option value="{{$paciente->id}}">{{ $paciente->nombre }}</option>
@endforeach
	</select><br>
 
	{{ Form::label("nombre", "Nombre") }} <br>
 	{{ Form::text("nombre") }} <br>
	{{ Form::label("apellido", "Apellido") }} <br>
 		{{ Form::text("apellido") }} <br>
	{{ Form::label("fecha","Fecha Ingreso") }} <br>
		{{ Form::text("dia") }} - 	{{ Form::text("mes") }} - 	{{ Form::text("anio") }} <br>

	{{ Form::submit("Modifica") }}
{{ Form::close() }}
@endsection