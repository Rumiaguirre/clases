<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<title>Document</title>
</head>
<body>
	@foreach ($pacientes as $paciente)
	{{ $paciente->nombre }}
@endforeach
</body>
</html>