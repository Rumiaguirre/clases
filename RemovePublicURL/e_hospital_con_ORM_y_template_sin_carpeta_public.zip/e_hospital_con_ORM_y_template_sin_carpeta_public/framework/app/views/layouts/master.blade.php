<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<title>@yield('titulo')</title>
</head>
<body>
	<ul>
		<li><a href="<?= URL::to("/"); ?>/consulta">Consulta</a></li>
		<li><a href="<?= URL::to("/"); ?>/ingreso">Ingreso</a></li>
		<li><a href="<?= URL::to("/"); ?>/baja">Baja</a></li>	
				<li><a href="<?= URL::to("/"); ?>/modifica">Modifica</a></li>	

	</ul>


<div class="content">
	@yield('contenido')
</div>
</body>
</html>