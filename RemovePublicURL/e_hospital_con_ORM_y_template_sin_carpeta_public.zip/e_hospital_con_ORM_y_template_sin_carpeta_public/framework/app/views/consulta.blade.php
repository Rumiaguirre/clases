@extends('layouts.master')

@section('titulo')
Consulta
@endsection

@section('contenido')
<table border="1px">
<tr><th>Nombre</th><th>Apellido</th><th>Fecha alta</th></tr>
	@foreach ($pacientes as $paciente)
<tr>

	<td>{{ $paciente->nombre }}</td>
	<td>{{$paciente->apellido}}</td>
	<td>{{$paciente->fecha_alta}}</td>
</tr>
@endforeach
@endsection