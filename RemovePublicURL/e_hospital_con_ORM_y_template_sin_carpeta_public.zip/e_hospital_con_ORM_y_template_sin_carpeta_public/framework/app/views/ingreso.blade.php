@extends('layouts.master')

@section('titulo')
Ingreso
@endsection

@section('contenido')
	{{ Form::open(array("url" => "ingreso2")) }} 
	{{ Form::label("nombre", "Nombre")}}
	{{ Form::text("nombre") }} <br>
		{{ Form::label("apellido", "Apellido")}}
	{{ Form::text("apellido") }} <br>

		{{ Form::label("fecha", "Fecha")}}
	{{ Form::text("dia") }} -{{ Form::text("mes") }} - {{ Form::text("anio") }}<br>
	{{ Form::submit("Enviar") }} 
{{ Form::close() }}
@endsection