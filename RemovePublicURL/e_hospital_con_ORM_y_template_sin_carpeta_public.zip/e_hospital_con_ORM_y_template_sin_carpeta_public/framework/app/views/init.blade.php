@extends('layouts.master')

@section('titulo')
Página de inicio
@endsection

@section('contenido')
Bienvenido
@endsection