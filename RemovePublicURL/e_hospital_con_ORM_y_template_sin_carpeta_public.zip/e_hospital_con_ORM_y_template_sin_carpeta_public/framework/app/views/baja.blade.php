@extends('layouts.master')

@section('titulo')
Baja
@endsection

@section('contenido')
{{ Form::open(array("url" => "baja2")) }} 
	{{ Form::label("paciente", "Paciente")}}

	<select name="id" id="">
@foreach ($pacientes as $paciente)
	<option value="{{$paciente->id}}">{{ $paciente->nombre }}</option>
@endforeach
	</select>
 
	{{ Form::submit("Baja") }}
{{ Form::close() }}
@endsection
